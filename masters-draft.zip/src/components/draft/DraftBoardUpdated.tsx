'use client';

import { useState, useEffect } from 'react';
import { DraftState, Player, Member } from '@/lib/types';
import { 
  initializeDraftState, 
  getCurrentMemberTurn,
  getOverallPickNumber,
  selectPlayer
} from '@/lib/data';
import { mastersPlayers } from '@/lib/sample-data';
import { saveDraftState, loadDraftState, exportDraftState, importDraftState } from '@/lib/storage';
import PlayerSelector from './PlayerSelector';
import MemberManager from './MemberManager';
import PlayerDataManager from './PlayerDataManager';
import DataPersistenceControls from './DataPersistenceControls';

export default function DraftBoardUpdated() {
  const [draftState, setDraftState] = useState<DraftState | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showSetup, setShowSetup] = useState(false);
  const [setupStep, setSetupStep] = useState<'members' | 'players'>('members');
  const [setupMembers, setSetupMembers] = useState<Member[]>([]);
  const [setupPlayers, setSetupPlayers] = useState<Player[]>(mastersPlayers);
  const [autoSaveEnabled, setAutoSaveEnabled] = useState(true);
  
  // Initialize or load draft state
  useEffect(() => {
    const savedState = loadDraftState();
    if (savedState) {
      setDraftState(savedState);
    } else {
      setShowSetup(true);
      // Initialize with 25 default members
      setSetupMembers(Array.from({ length: 25 }, (_, i) => ({
        id: (i + 1).toString(),
        name: `Member ${i + 1}`,
        selections: [],
      })));
    }
    setIsLoading(false);
  }, []);
  
  // Save draft state when it changes
  useEffect(() => {
    if (draftState && autoSaveEnabled) {
      saveDraftState(draftState);
    }
  }, [draftState, autoSaveEnabled]);
  
  // Initialize new draft
  const initializeNewDraft = () => {
    const newState = {
      members: setupMembers,
      players: setupPlayers,
      currentRound: 1,
      currentPick: 1,
      isSnakeDraft: true,
      isDraftComplete: false,
      totalRounds: Math.ceil(setupPlayers.length / setupMembers.length),
    };
    
    setDraftState(newState);
    setShowSetup(false);
  };
  
  // Handle player selection
  const handleSelectPlayer = (playerId: string) => {
    if (!draftState) return;
    
    const updatedState = selectPlayer(draftState, playerId);
    setDraftState(updatedState);
  };
  
  // Reset draft
  const resetDraft = () => {
    localStorage.removeItem('mastersDraftState');
    setDraftState(null);
    setShowSetup(true);
    setSetupStep('members');
  };
  
  // Handle setup navigation
  const handleNextSetupStep = () => {
    if (setupStep === 'members') {
      setSetupStep('players');
    } else {
      initializeNewDraft();
    }
  };
  
  const handlePrevSetupStep = () => {
    if (setupStep === 'players') {
      setSetupStep('members');
    }
  };
  
  // Handle import
  const handleImport = (importedState: DraftState) => {
    setDraftState(importedState);
    setShowSetup(false);
  };
  
  // Manual save
  const handleManualSave = () => {
    if (draftState) {
      saveDraftState(draftState);
      alert('Draft state saved successfully!');
    }
  };
  
  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-blue-500"></div>
      </div>
    );
  }
  
  if (showSetup) {
    return (
      <div className="container mx-auto p-4">
        <div className="text-center mb-6">
          <h1 className="text-3xl font-bold mb-2">2025 Masters Draft</h1>
        </div>
        
        {/* Data import option */}
        <div className="bg-white shadow rounded-lg p-4 mb-6">
          <p className="mb-2">You can import an existing draft or set up a new one:</p>
          <DataPersistenceControls 
            draftState={null} 
            onImport={handleImport} 
            disabled={false} 
          />
        </div>
        
        {/* Rules */}
        <div className="bg-white border-l-4 border-yellow-400 p-4 mb-6 rounded-lg shadow">
          <p className="font-bold">Draft Rules:</p>
          <ul className="list-disc pl-5">
            <li>This is a snake draft format</li>
            <li>No member is allowed to make edits once a player is picked</li>
            <li>You can configure members before starting the draft</li>
          </ul>
        </div>
        
        {/* Setup steps indicator */}
        <div className="flex mb-6 mt-8 rounded-lg overflow-hidden">
          <div className={`flex-1 text-center py-3 font-bold ${setupStep === 'members' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700'}`}>
            1. Configure Members
          </div>
          <div className={`flex-1 text-center py-3 font-bold ${setupStep === 'players' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700'}`}>
            2. Configure Players
          </div>
        </div>
        
        {setupStep === 'members' && (
          <div className="bg-white shadow rounded-lg p-4">
            <p className="mb-4">Configure the members participating in your draft. You can add, edit, or remove members.</p>
            <MemberManager 
              members={setupMembers} 
              onUpdateMembers={setSetupMembers} 
              disabled={false} 
            />
          </div>
        )}
        
        {setupStep === 'players' && (
          <div className="bg-white shadow rounded-lg p-4">
            <p className="mb-4">Configure the players available for selection in your draft. You can add individual players or import them in bulk.</p>
            <PlayerDataManager 
              initialPlayers={setupPlayers} 
              onPlayersUpdated={setSetupPlayers} 
              disabled={false} 
            />
          </div>
        )}
        
        <div className="flex justify-between mt-6">
          {setupStep === 'players' && (
            <button
              onClick={handlePrevSetupStep}
              className="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600"
            >
              Back to Members
            </button>
          )}
          {setupStep === 'members' && (
            <div></div> // Empty div for spacing
          )}
          <button
            onClick={handleNextSetupStep}
            className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
            disabled={setupStep === 'members' && setupMembers.length === 0 || setupStep === 'players' && setupPlayers.length === 0}
          >
            {setupStep === 'players' ? 'Start Draft' : 'Next: Configure Players'}
          </button>
        </div>
      </div>
    );
  }
  
  if (!draftState) return null;
  
  const currentMember = getCurrentMemberTurn(draftState);
  const overallPick = getOverallPickNumber(draftState);
  const availablePlayers = draftState.players.filter(player => !player.selected);
  
  return (
    <div className="container mx-auto p-4">
      <div className="text-center mb-6">
        <h1 className="text-3xl font-bold mb-2">2025 Masters Draft</h1>
      </div>
      
      {/* Rules */}
      <div className="bg-white border-l-4 border-yellow-400 p-4 mb-6 rounded-lg shadow">
        <p className="font-bold">Draft Rules:</p>
        <ul className="list-disc pl-5">
          <li>This is a snake draft format</li>
          <li>No member is allowed to make edits once a player is picked</li>
        </ul>
      </div>
      
      {/* Draft Status */}
      <div className="bg-gray-100 p-4 rounded-lg shadow mb-4">
        {draftState.isDraftComplete ? (
          <div className="text-xl font-bold text-green-600">Draft Complete!</div>
        ) : (
          <>
            <div className="text-lg">
              Round: <span className="font-bold">{draftState.currentRound}</span> | 
              Pick: <span className="font-bold">{draftState.currentPick}</span> | 
              Overall: <span className="font-bold">{overallPick}</span>
            </div>
            <div className="text-xl font-bold text-blue-600">
              Current Pick: {currentMember?.name || 'Unknown'}
            </div>
          </>
        )}
        <div className="flex mt-2 space-x-2">
          <button
            onClick={resetDraft}
            className="bg-red-600 text-white px-3 py-1 rounded hover:bg-red-700"
          >
            Reset Draft
          </button>
          <button
            onClick={handleManualSave}
            className="bg-blue-500 text-white px-3 py-1 rounded hover:bg-blue-600"
          >
            Save Draft
          </button>
          <div className="flex items-center ml-4">
            <input
              type="checkbox"
              id="autoSave"
              checked={autoSaveEnabled}
              onChange={(e) => setAutoSaveEnabled(e.target.checked)}
              className="mr-2"
            />
            <label htmlFor="autoSave">Auto-save</label>
          </div>
        </div>
      </div>
      
      {/* Data Persistence Controls */}
      <div className="bg-white shadow rounded-lg p-4 mb-4">
        <DataPersistenceControls 
          draftState={draftState} 
          onImport={handleImport} 
          disabled={false} 
        />
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Available Players */}
        <div>
          <h2 className="text-xl font-bold mb-2">Available Players</h2>
          <PlayerSelector 
            players={availablePlayers}
            onSelectPlayer={handleSelectPlayer}
            disabled={draftState.isDraftComplete || !currentMember}
          />
        </div>
        
        {/* Draft Results */}
        <div>
          <h2 className="text-xl font-bold mb-2">Draft Results</h2>
          <div className="bg-white shadow rounded-lg overflow-hidden">
            <table className="min-w-full">
              <thead className="bg-gray-100">
                <tr>
                  <th className="py-2 px-4 text-left">Pick</th>
                  <th className="py-2 px-4 text-left">Member</th>
                  <th className="py-2 px-4 text-left">Player</th>
                  <th className="py-2 px-4 text-left">OWGR</th>
                </tr>
              </thead>
              <tbody>
                {draftState.players
                  .filter(player => player.selected)
                  .sort((a, b) => (a.draftPosition || 0) - (b.draftPosition || 0))
                  .map(player => {
                    const member = draftState.members.find(m => m.id === player.selectedBy);
                    return (
                      <tr key={player.id} className="border-t hover:bg-gray-50">
                        <td className="py-2 px-4">{player.draftPosition}</td>
                        <td className="py-2 px-4">{member?.name || 'Unknown'}</td>
                        <td className="py-2 px-4 font-bold">{player.name}</td>
                        <td className="py-2 px-4">{player.worldGolfRanking}</td>
                      </tr>
                    );
                  })}
                {draftState.players.filter(player => player.selected).length === 0 && (
                  <tr>
                    <td colSpan={4} className="py-4 px-4 text-center text-gray-500">
                      No players selected yet
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
      
      {/* Member Selections */}
      <div className="mt-8">
        <h2 className="text-xl font-bold mb-2">Member Selections</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {draftState.members.map(member => (
            <div key={member.id} className="bg-white shadow rounded-lg p-4">
              <h3 className="font-bold text-lg mb-2 text-blue-600">{member.name}</h3>
              <ul>
                {member.selections.map(player => (
                  <li key={player.id} className="mb-1 bg-gray-50 p-2 rounded">
                    <span className="font-bold">{player.name}</span> 
                    <div className="text-sm text-gray-600">
                      OWGR: {player.worldGolfRanking} 
                      {player.lastYearPlace && ` | Last Year: ${player.lastYearPlace}`}
                    </div>
                  </li>
                ))}
                {member.selections.length === 0 && (
                  <li className="text-gray-500">No selections yet</li>
                )}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
