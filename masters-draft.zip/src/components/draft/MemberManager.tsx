'use client';

import { useState } from 'react';
import { Member } from '@/lib/types';

interface MemberManagerProps {
  members: Member[];
  onUpdateMembers: (members: Member[]) => void;
  disabled: boolean;
}

export default function MemberManager({ members, onUpdateMembers, disabled }: MemberManagerProps) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [newMemberName, setNewMemberName] = useState('');
  
  // Add a new member
  const handleAddMember = () => {
    if (!newMemberName.trim()) return;
    
    const newMember: Member = {
      id: (members.length + 1).toString(),
      name: newMemberName,
      selections: []
    };
    
    onUpdateMembers([...members, newMember]);
    setNewMemberName('');
  };
  
  // Update member name
  const handleUpdateMember = (id: string, name: string) => {
    const updatedMembers = members.map(member => 
      member.id === id ? { ...member, name } : member
    );
    onUpdateMembers(updatedMembers);
    setEditingId(null);
  };
  
  // Remove a member
  const handleRemoveMember = (id: string) => {
    const updatedMembers = members.filter(member => member.id !== id);
    onUpdateMembers(updatedMembers);
  };
  
  return (
    <div className="space-y-4">
      {/* Add new member form */}
      <div className="flex space-x-2 mb-4">
        <input
          type="text"
          value={newMemberName}
          onChange={(e) => setNewMemberName(e.target.value)}
          placeholder="Enter member name"
          className="w-full p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent flex-grow"
          disabled={disabled}
        />
        <button
          onClick={handleAddMember}
          disabled={!newMemberName.trim() || disabled}
          className={`bg-blue-500 text-white px-4 py-2 rounded ${(!newMemberName.trim() || disabled) ? 'opacity-50 cursor-not-allowed' : 'hover:bg-blue-600'}`}
        >
          Add Member
        </button>
      </div>
      
      {/* Member list */}
      <div className="max-h-96 overflow-y-auto">
        {members.length === 0 ? (
          <div className="text-center py-4 text-gray-500">No members added yet</div>
        ) : (
          <div className="space-y-2">
            {members.map(member => (
              <div key={member.id} className="bg-white shadow rounded-lg p-4 flex justify-between items-center">
                {editingId === member.id ? (
                  <input
                    type="text"
                    defaultValue={member.name}
                    className="w-full p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent mr-2"
                    autoFocus
                    onBlur={(e) => handleUpdateMember(member.id, e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        handleUpdateMember(member.id, e.currentTarget.value);
                      }
                    }}
                  />
                ) : (
                  <div className="font-bold text-blue-600">{member.name}</div>
                )}
                
                <div className="flex space-x-2">
                  {editingId !== member.id && (
                    <button
                      onClick={() => setEditingId(member.id)}
                      disabled={disabled}
                      className={`text-blue-600 hover:text-blue-800 ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                      </svg>
                    </button>
                  )}
                  
                  <button
                    onClick={() => handleRemoveMember(member.id)}
                    disabled={disabled}
                    className={`text-red-600 hover:text-red-800 ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
                  >
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                    </svg>
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
      
      <div className="mt-4 text-sm text-gray-500">
        Total members: {members.length}
      </div>
    </div>
  );
}
