'use client';

import { useState, useEffect } from 'react';
import { Player } from '@/lib/types';

interface PlayerSelectorProps {
  players: Player[];
  onSelectPlayer: (playerId: string) => void;
  disabled: boolean;
}

export default function PlayerSelector({ players, onSelectPlayer, disabled }: PlayerSelectorProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSort] = useState<'name' | 'worldGolfRanking' | 'lastYearPlace'>('worldGolfRanking');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [currentPage, setCurrentPage] = useState(1);
  const [showSortOptions, setShowSortOptions] = useState(false);
  const playersPerPage = 10;
  
  // Filter and sort players
  const filteredPlayers = players.filter(player => 
    player.name.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  const sortedPlayers = [...filteredPlayers].sort((a, b) => {
    if (sortBy === 'name') {
      return sortDirection === 'asc' 
        ? a.name.localeCompare(b.name)
        : b.name.localeCompare(a.name);
    } else if (sortBy === 'worldGolfRanking') {
      const rankA = a.worldGolfRanking === 999 ? 999 : a.worldGolfRanking;
      const rankB = b.worldGolfRanking === 999 ? 999 : b.worldGolfRanking;
      return sortDirection === 'asc' 
        ? rankA - rankB
        : rankB - rankA;
    } else {
      // Handle null values for lastYearPlace
      const placeA = a.lastYearPlace === null ? 999 : a.lastYearPlace;
      const placeB = b.lastYearPlace === null ? 999 : b.lastYearPlace;
      return sortDirection === 'asc' 
        ? placeA - placeB
        : placeB - placeA;
    }
  });
  
  // Pagination
  const totalPages = Math.ceil(sortedPlayers.length / playersPerPage);
  const currentPlayers = sortedPlayers.slice(
    (currentPage - 1) * playersPerPage,
    currentPage * playersPerPage
  );
  
  // Reset to first page when search changes
  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm]);
  
  // Handle sort toggle
  const handleSortChange = (field: 'name' | 'worldGolfRanking' | 'lastYearPlace') => {
    if (sortBy === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSort(field);
      setSortDirection('asc');
    }
    setShowSortOptions(false);
  };
  
  return (
    <div className="bg-white shadow rounded-lg p-4">
      {/* Search and sort controls */}
      <div className="mb-4">
        <div className="relative">
          <input
            type="text"
            placeholder="Search players..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full p-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
          <div className="absolute right-2 top-2">
            <button 
              onClick={() => setShowSortOptions(!showSortOptions)}
              className="text-blue-500 hover:text-blue-700"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4h13M3 8h9m-9 4h6m4 0l4-4m0 0l4 4m-4-4v12" />
              </svg>
            </button>
          </div>
        </div>
        
        {/* Sort options dropdown */}
        {showSortOptions && (
          <div className="absolute z-10 mt-1 bg-white shadow-lg rounded-lg overflow-hidden border border-gray-200">
            <div 
              className="py-2 px-4 text-left cursor-pointer hover:bg-gray-200 font-bold text-blue-600"
              onClick={() => handleSortChange('name')}
            >
              Name {sortBy === 'name' && (sortDirection === 'asc' ? '↑' : '↓')}
            </div>
            <div 
              className="py-2 px-4 text-left cursor-pointer hover:bg-gray-200 font-bold text-blue-600"
              onClick={() => handleSortChange('worldGolfRanking')}
            >
              World Ranking {sortBy === 'worldGolfRanking' && (sortDirection === 'asc' ? '↑' : '↓')}
            </div>
            <div 
              className="py-2 px-4 text-left cursor-pointer hover:bg-gray-200 font-bold text-blue-600"
              onClick={() => handleSortChange('lastYearPlace')}
            >
              Last Year's Place {sortBy === 'lastYearPlace' && (sortDirection === 'asc' ? '↑' : '↓')}
            </div>
          </div>
        )}
      </div>
      
      {/* Player list */}
      <div className="max-h-96 overflow-y-auto">
        {currentPlayers.length === 0 ? (
          <div className="text-center py-4 text-gray-500">No players found</div>
        ) : (
          <div className="space-y-2">
            {currentPlayers.map(player => (
              <div key={player.id} className="bg-gray-50 p-3 rounded-lg flex justify-between items-center">
                <div>
                  <div className="font-bold">{player.name}</div>
                  <div className="text-sm text-gray-600">
                    OWGR: {player.worldGolfRanking === 999 ? 'Amateur' : player.worldGolfRanking}
                    {player.lastYearPlace !== null && ` | Last Year: ${player.lastYearPlace}`}
                  </div>
                </div>
                <button
                  onClick={() => onSelectPlayer(player.id)}
                  disabled={disabled}
                  className={`bg-blue-500 text-white px-3 py-1 rounded text-sm ${disabled ? 'opacity-50 cursor-not-allowed' : 'hover:bg-blue-600'}`}
                >
                  Select
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
      
      {/* Pagination */}
      {totalPages > 1 && (
        <div className="flex justify-center mt-4">
          <button
            onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
            disabled={currentPage === 1}
            className={`px-3 py-1 mx-1 rounded ${currentPage === 1 ? 'bg-gray-200 text-gray-700' : 'bg-blue-500 text-white'}`}
          >
            &lt;
          </button>
          
          {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
            // Show pages around current page
            let pageNum;
            if (totalPages <= 5) {
              pageNum = i + 1;
            } else if (currentPage <= 3) {
              pageNum = i + 1;
            } else if (currentPage >= totalPages - 2) {
              pageNum = totalPages - 4 + i;
            } else {
              pageNum = currentPage - 2 + i;
            }
            
            return (
              <button
                key={pageNum}
                onClick={() => setCurrentPage(pageNum)}
                className={`px-3 py-1 mx-1 rounded ${currentPage === pageNum ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`}
              >
                {pageNum}
              </button>
            );
          })}
          
          <button
            onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
            disabled={currentPage === totalPages}
            className={`px-3 py-1 mx-1 rounded ${currentPage === totalPages ? 'bg-gray-200 text-gray-700' : 'bg-blue-500 text-white'}`}
          >
            &gt;
          </button>
        </div>
      )}
      
      <div className="mt-4 text-sm text-gray-500">
        Showing {currentPlayers.length} of {filteredPlayers.length} players
      </div>
    </div>
  );
}
