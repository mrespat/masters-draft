'use client';

import { useState, useEffect } from 'react';
import { Player } from '@/lib/types';

interface PlayerDataManagerProps {
  onPlayersUpdated: (players: Player[]) => void;
  initialPlayers: Player[];
  disabled: boolean;
}

export default function PlayerDataManager({ onPlayersUpdated, initialPlayers, disabled }: PlayerDataManagerProps) {
  const [players, setPlayers] = useState<Player[]>(initialPlayers);
  const [newPlayer, setNewPlayer] = useState<Omit<Player, 'id' | 'selected' | 'selectedBy' | 'draftPosition'>>({
    name: '',
    lastYearPlace: null,
    worldGolfRanking: 0
  });
  const [bulkImportText, setBulkImportText] = useState('');
  const [showBulkImport, setShowBulkImport] = useState(false);
  
  // Update parent component when players change
  useEffect(() => {
    onPlayersUpdated(players);
  }, [players, onPlayersUpdated]);
  
  // Add new player
  const handleAddPlayer = () => {
    if (!newPlayer.name.trim()) return;
    
    const newPlayerComplete: Player = {
      id: Date.now().toString(),
      name: newPlayer.name.trim(),
      lastYearPlace: newPlayer.lastYearPlace,
      worldGolfRanking: newPlayer.worldGolfRanking,
      selected: false,
      selectedBy: null,
      draftPosition: null
    };
    
    setPlayers([...players, newPlayerComplete]);
    setNewPlayer({
      name: '',
      lastYearPlace: null,
      worldGolfRanking: 0
    });
  };
  
  // Remove player
  const handleRemovePlayer = (id: string) => {
    const updatedPlayers = players.filter(player => player.id !== id);
    setPlayers(updatedPlayers);
  };
  
  // Handle bulk import
  const handleBulkImport = () => {
    if (!bulkImportText.trim()) return;
    
    try {
      // Expected format: Name, Last Year Place, OWGR (one per line)
      const lines = bulkImportText.trim().split('\n');
      const newPlayers: Player[] = lines.map(line => {
        const [name, lastYearPlace, worldGolfRanking] = line.split(',').map(item => item.trim());
        
        return {
          id: Date.now() + Math.random().toString(),
          name,
          lastYearPlace: lastYearPlace === 'N/A' ? null : Number(lastYearPlace),
          worldGolfRanking: Number(worldGolfRanking) || 999, // Default to 999 if not provided
          selected: false,
          selectedBy: null,
          draftPosition: null
        };
      });
      
      setPlayers([...players, ...newPlayers]);
      setBulkImportText('');
      setShowBulkImport(false);
    } catch (error) {
      alert('Error importing players. Please check the format.');
      console.error('Import error:', error);
    }
  };
  
  // Export players to CSV
  const handleExportPlayers = () => {
    const csvContent = players.map(player => 
      `${player.name},${player.lastYearPlace ?? 'N/A'},${player.worldGolfRanking}`
    ).join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'masters_players.csv';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };
  
  return (
    <div className="bg-white shadow rounded p-4">
      <h2 className="text-xl font-bold mb-4">Manage Players</h2>
      
      {/* Add new player form */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-2 mb-4">
        <input
          type="text"
          placeholder="Player name"
          value={newPlayer.name}
          onChange={(e) => setNewPlayer({...newPlayer, name: e.target.value})}
          disabled={disabled}
          className="p-2 border rounded"
        />
        <input
          type="number"
          placeholder="Last year place (optional)"
          value={newPlayer.lastYearPlace === null ? '' : newPlayer.lastYearPlace}
          onChange={(e) => setNewPlayer({
            ...newPlayer, 
            lastYearPlace: e.target.value === '' ? null : Number(e.target.value)
          })}
          disabled={disabled}
          className="p-2 border rounded"
        />
        <input
          type="number"
          placeholder="World Golf Ranking"
          value={newPlayer.worldGolfRanking}
          onChange={(e) => setNewPlayer({
            ...newPlayer, 
            worldGolfRanking: Number(e.target.value) || 0
          })}
          disabled={disabled}
          className="p-2 border rounded"
        />
      </div>
      
      <div className="flex space-x-2 mb-4">
        <button
          onClick={handleAddPlayer}
          disabled={disabled || !newPlayer.name.trim()}
          className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 disabled:bg-gray-400"
        >
          Add Player
        </button>
        <button
          onClick={() => setShowBulkImport(!showBulkImport)}
          disabled={disabled}
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 disabled:bg-gray-400"
        >
          {showBulkImport ? 'Hide Bulk Import' : 'Bulk Import'}
        </button>
        <button
          onClick={handleExportPlayers}
          disabled={disabled || players.length === 0}
          className="bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700 disabled:bg-gray-400"
        >
          Export Players
        </button>
      </div>
      
      {/* Bulk import form */}
      {showBulkImport && (
        <div className="mb-4">
          <p className="text-sm text-gray-600 mb-2">
            Enter one player per line in format: Name, Last Year Place, OWGR
            <br />
            Example: Scottie Scheffler, 10, 1
          </p>
          <textarea
            value={bulkImportText}
            onChange={(e) => setBulkImportText(e.target.value)}
            disabled={disabled}
            rows={5}
            className="w-full p-2 border rounded mb-2"
            placeholder="Scottie Scheffler, 10, 1&#10;Rory McIlroy, 2, 2&#10;Jon Rahm, 15, 3"
          />
          <button
            onClick={handleBulkImport}
            disabled={disabled || !bulkImportText.trim()}
            className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 disabled:bg-gray-400"
          >
            Import Players
          </button>
        </div>
      )}
      
      {/* Player list */}
      <div className="mt-4">
        <h3 className="font-bold mb-2">Current Players ({players.length})</h3>
        <div className="max-h-60 overflow-y-auto">
          <table className="min-w-full">
            <thead className="bg-gray-100">
              <tr>
                <th className="py-2 px-4 text-left">Name</th>
                <th className="py-2 px-4 text-left">Last Year</th>
                <th className="py-2 px-4 text-left">OWGR</th>
                <th className="py-2 px-4 text-left">Action</th>
              </tr>
            </thead>
            <tbody>
              {players.map(player => (
                <tr key={player.id} className="border-t">
                  <td className="py-2 px-4">{player.name}</td>
                  <td className="py-2 px-4">{player.lastYearPlace ?? 'N/A'}</td>
                  <td className="py-2 px-4">{player.worldGolfRanking}</td>
                  <td className="py-2 px-4">
                    <button
                      onClick={() => handleRemovePlayer(player.id)}
                      disabled={disabled || player.selected}
                      className="text-red-600 hover:text-red-800 disabled:text-gray-400"
                    >
                      Remove
                    </button>
                  </td>
                </tr>
              ))}
              {players.length === 0 && (
                <tr>
                  <td colSpan={4} className="py-4 px-4 text-center text-gray-500">
                    No players added yet
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
