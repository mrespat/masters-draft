'use client';

import { useState, useEffect } from 'react';
import { DraftState, Player } from '@/lib/types';
import { 
  initializeDraftState, 
  getCurrentMemberTurn,
  getOverallPickNumber,
  selectPlayer
} from '@/lib/data';
import { mastersPlayers } from '@/lib/sample-data';
import { saveDraftState, loadDraftState } from '@/lib/storage';
import PlayerSelector from './PlayerSelector';
import MemberManager from './MemberManager';
import PlayerDataManager from './PlayerDataManager';

export default function DraftBoard() {
  const [draftState, setDraftState] = useState<DraftState | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showSetup, setShowSetup] = useState(false);
  
  // Initialize or load draft state
  useEffect(() => {
    const savedState = loadDraftState();
    if (savedState) {
      setDraftState(savedState);
    } else {
      setShowSetup(true);
    }
    setIsLoading(false);
  }, []);
  
  // Save draft state when it changes
  useEffect(() => {
    if (draftState) {
      saveDraftState(draftState);
    }
  }, [draftState]);
  
  // Initialize new draft
  const initializeNewDraft = () => {
    const newState = initializeDraftState(25, mastersPlayers);
    setDraftState(newState);
    setShowSetup(false);
  };
  
  // Handle player selection
  const handleSelectPlayer = (playerId: string) => {
    if (!draftState) return;
    
    const updatedState = selectPlayer(draftState, playerId);
    setDraftState(updatedState);
  };
  
  // Reset draft
  const resetDraft = () => {
    localStorage.removeItem('mastersDraftState');
    setDraftState(null);
    setShowSetup(true);
  };
  
  if (isLoading) {
    return <div className="flex justify-center items-center h-screen">Loading...</div>;
  }
  
  if (showSetup) {
    return (
      <div className="container mx-auto p-4">
        <h1 className="text-2xl font-bold mb-4">Masters Tournament Fantasy Draft Setup</h1>
        <div className="mb-4">
          <button
            onClick={initializeNewDraft}
            className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
          >
            Start Draft
          </button>
        </div>
      </div>
    );
  }
  
  if (!draftState) return null;
  
  const currentMember = getCurrentMemberTurn(draftState);
  const overallPick = getOverallPickNumber(draftState);
  const availablePlayers = draftState.players.filter(player => !player.selected);
  
  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">Masters Tournament Fantasy Draft</h1>
      
      {/* Draft Status */}
      <div className="bg-gray-100 p-4 rounded mb-4">
        {draftState.isDraftComplete ? (
          <div className="text-xl font-bold text-green-600">Draft Complete!</div>
        ) : (
          <>
            <div className="text-lg">
              Round: {draftState.currentRound} | Pick: {draftState.currentPick} | Overall: {overallPick}
            </div>
            <div className="text-xl font-bold">
              Current Pick: {currentMember?.name || 'Unknown'}
            </div>
          </>
        )}
        <button
          onClick={resetDraft}
          className="bg-red-600 text-white px-3 py-1 rounded hover:bg-red-700 mt-2"
        >
          Reset Draft
        </button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Available Players */}
        <div>
          <h2 className="text-xl font-bold mb-2">Available Players</h2>
          <PlayerSelector 
            players={availablePlayers}
            onSelectPlayer={handleSelectPlayer}
            disabled={draftState.isDraftComplete || !currentMember}
          />
        </div>
        
        {/* Draft Results */}
        <div>
          <h2 className="text-xl font-bold mb-2">Draft Results</h2>
          <div className="bg-white shadow rounded overflow-hidden">
            <table className="min-w-full">
              <thead className="bg-gray-100">
                <tr>
                  <th className="py-2 px-4 text-left">Pick</th>
                  <th className="py-2 px-4 text-left">Member</th>
                  <th className="py-2 px-4 text-left">Player</th>
                  <th className="py-2 px-4 text-left">OWGR</th>
                </tr>
              </thead>
              <tbody>
                {draftState.players
                  .filter(player => player.selected)
                  .sort((a, b) => (a.draftPosition || 0) - (b.draftPosition || 0))
                  .map(player => {
                    const member = draftState.members.find(m => m.id === player.selectedBy);
                    return (
                      <tr key={player.id} className="border-t">
                        <td className="py-2 px-4">{player.draftPosition}</td>
                        <td className="py-2 px-4">{member?.name || 'Unknown'}</td>
                        <td className="py-2 px-4">{player.name}</td>
                        <td className="py-2 px-4">{player.worldGolfRanking}</td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>
        </div>
      </div>
      
      {/* Member Selections */}
      <div className="mt-8">
        <h2 className="text-xl font-bold mb-2">Member Selections</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {draftState.members.map(member => (
            <div key={member.id} className="bg-white shadow rounded p-4">
              <h3 className="font-bold text-lg mb-2">{member.name}</h3>
              <ul>
                {member.selections.map(player => (
                  <li key={player.id} className="mb-1">
                    {player.name} (OWGR: {player.worldGolfRanking})
                  </li>
                ))}
                {member.selections.length === 0 && (
                  <li className="text-gray-500">No selections yet</li>
                )}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
