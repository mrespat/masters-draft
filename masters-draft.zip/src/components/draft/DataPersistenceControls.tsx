'use client';

import { useState } from 'react';
import { DraftState } from '@/lib/types';

interface DataPersistenceControlsProps {
  draftState: DraftState | null;
  onImport: (importedState: DraftState) => void;
  disabled: boolean;
}

export default function DataPersistenceControls({ 
  draftState, 
  onImport, 
  disabled 
}: DataPersistenceControlsProps) {
  const [importError, setImportError] = useState<string | null>(null);
  
  // Export draft state
  const handleExport = () => {
    if (!draftState) return;
    
    const dataStr = JSON.stringify(draftState);
    const dataUri = `data:application/json;charset=utf-8,${encodeURIComponent(dataStr)}`;
    
    const exportFileDefaultName = `masters-draft-${new Date().toISOString().slice(0, 10)}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  };
  
  // Import draft state
  const handleImport = (event: React.ChangeEvent<HTMLInputElement>) => {
    setImportError(null);
    const fileReader = new FileReader();
    const file = event.target.files?.[0];
    
    if (!file) return;
    
    fileReader.readAsText(file, "UTF-8");
    fileReader.onload = e => {
      try {
        const content = e.target?.result as string;
        const parsedData = JSON.parse(content) as DraftState;
        
        // Basic validation
        if (!parsedData.members || !parsedData.players) {
          throw new Error("Invalid draft data format");
        }
        
        onImport(parsedData);
      } catch (error) {
        console.error("Import error:", error);
        setImportError("Failed to import data. Please check the file format.");
      }
    };
    fileReader.onerror = () => {
      setImportError("Error reading file");
    };
    
    // Reset the input
    event.target.value = '';
  };
  
  return (
    <div className="space-y-2">
      <div className="flex flex-wrap gap-2">
        <button
          onClick={handleExport}
          disabled={!draftState || disabled}
          className={`btn-primary flex items-center ${(!draftState || disabled) ? 'opacity-50 cursor-not-allowed' : ''}`}
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
          </svg>
          Export Draft Data
        </button>
        
        <label className={`btn-secondary flex items-center cursor-pointer ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}>
          <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
          </svg>
          Import Draft Data
          <input
            type="file"
            accept=".json"
            onChange={handleImport}
            disabled={disabled}
            className="hidden"
          />
        </label>
      </div>
      
      {importError && (
        <div className="text-red-600 text-sm mt-1">{importError}</div>
      )}
      
      <p className="text-sm text-gray-600 mt-2">
        Export your draft data to save it for later or share with others. 
        Import previously exported data to continue a draft.
      </p>
    </div>
  );
}
