import DraftBoardUpdated from '@/components/draft/DraftBoardUpdated';

export default function Home() {
  return (
    <main className="min-h-screen bg-gray-50">
      <DraftBoardUpdated />
    </main>
  );
}
