import { Metadata } from 'next';
 
export const metadata: Metadata = {
  title: '2025 Masters Draft',
  description: 'Fantasy draft application for the 2025 Masters Tournament',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
