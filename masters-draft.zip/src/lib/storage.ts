'use client';

import { DraftState } from '@/lib/types';

// Save draft state to local storage
export const saveDraftState = (state: DraftState): void => {
  if (typeof window !== 'undefined') {
    try {
      localStorage.setItem('mastersDraftState', JSON.stringify(state));
      console.log('Draft state saved successfully');
    } catch (error) {
      console.error('Error saving draft state:', error);
    }
  }
};

// Load draft state from local storage
export const loadDraftState = (): DraftState | null => {
  if (typeof window !== 'undefined') {
    try {
      const savedState = localStorage.getItem('mastersDraftState');
      if (savedState) {
        return JSON.parse(savedState);
      }
    } catch (error) {
      console.error('Error loading draft state:', error);
    }
  }
  return null;
};

// Export draft state to a file
export const exportDraftState = (state: DraftState): void => {
  try {
    const dataStr = JSON.stringify(state, null, 2);
    const dataUri = `data:application/json;charset=utf-8,${encodeURIComponent(dataStr)}`;
    
    const exportFileDefaultName = `masters_draft_${new Date().toISOString().slice(0, 10)}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
  } catch (error) {
    console.error('Error exporting draft state:', error);
  }
};

// Import draft state from a file
export const importDraftState = (file: File): Promise<DraftState> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    reader.onload = (event) => {
      try {
        const result = event.target?.result;
        if (typeof result === 'string') {
          const importedState = JSON.parse(result) as DraftState;
          resolve(importedState);
        } else {
          reject(new Error('Invalid file content'));
        }
      } catch (error) {
        reject(error);
      }
    };
    
    reader.onerror = () => {
      reject(new Error('Error reading file'));
    };
    
    reader.readAsText(file);
  });
};
