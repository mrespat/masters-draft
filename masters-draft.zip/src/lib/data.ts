import { mastersPlayers } from './sample-data';
import { Player, Member, DraftState } from './types';

// Generate sample members
export const generateSampleMembers = (count: number): Member[] => {
  return Array.from({ length: count }, (_, i) => ({
    id: (i + 1).toString(),
    name: `Member ${i + 1}`,
    selections: [],
  }));
};

// Initialize draft state
export const initializeDraftState = (memberCount: number, players: Player[] = mastersPlayers): DraftState => {
  return {
    members: generateSampleMembers(memberCount),
    players,
    currentRound: 1,
    currentPick: 1,
    isSnakeDraft: true,
    isDraftComplete: false,
    totalRounds: Math.ceil(players.length / memberCount),
  };
};

// Get current member's turn
export const getCurrentMemberTurn = (state: DraftState): Member | null => {
  if (state.isDraftComplete) return null;
  
  const totalMembers = state.members.length;
  let pickInRound = state.currentPick;
  
  // For even-numbered rounds in snake draft, reverse the order
  if (state.isSnakeDraft && state.currentRound % 2 === 0) {
    pickInRound = totalMembers - pickInRound + 1;
  }
  
  return state.members[pickInRound - 1] || null;
};

// Calculate the overall pick number
export const getOverallPickNumber = (state: DraftState): number => {
  return (state.currentRound - 1) * state.members.length + state.currentPick;
};

// Move to next pick
export const moveToNextPick = (state: DraftState): DraftState => {
  const totalMembers = state.members.length;
  let nextPick = state.currentPick + 1;
  let nextRound = state.currentRound;
  
  if (nextPick > totalMembers) {
    nextPick = 1;
    nextRound++;
  }
  
  const totalPicks = state.players.length;
  const currentOverallPick = getOverallPickNumber({...state, currentPick: nextPick, currentRound: nextRound});
  const isDraftComplete = currentOverallPick > totalPicks;
  
  return {
    ...state,
    currentPick: nextPick,
    currentRound: nextRound,
    isDraftComplete,
  };
};

// Select a player
export const selectPlayer = (state: DraftState, playerId: string): DraftState => {
  const currentMember = getCurrentMemberTurn(state);
  if (!currentMember || state.isDraftComplete) return state;
  
  const updatedPlayers = state.players.map(player => {
    if (player.id === playerId) {
      return {
        ...player,
        selected: true,
        selectedBy: currentMember.id,
        draftPosition: getOverallPickNumber(state),
      };
    }
    return player;
  });
  
  const updatedMembers = state.members.map(member => {
    if (member.id === currentMember.id) {
      const selectedPlayer = updatedPlayers.find(p => p.id === playerId);
      if (selectedPlayer) {
        return {
          ...member,
          selections: [...member.selections, selectedPlayer],
        };
      }
    }
    return member;
  });
  
  const updatedState = {
    ...state,
    players: updatedPlayers,
    members: updatedMembers,
  };
  
  return moveToNextPick(updatedState);
};
