export interface Player {
  id: string;
  name: string;
  lastYearPlace: number | null; // null if they didn't play last year
  worldGolfRanking: number;
  selected: boolean;
  selectedBy: string | null;
  draftPosition: number | null;
}

export interface Member {
  id: string;
  name: string;
  selections: Player[];
}

export interface DraftState {
  members: Member[];
  players: Player[];
  currentRound: number;
  currentPick: number;
  isSnakeDraft: boolean;
  isDraftComplete: boolean;
  totalRounds: number;
}
