/**
 * Masters Draft GitHub Pages Configuration
 * This file configures the Next.js application for GitHub Pages deployment.
 */
/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'export',
  distDir: 'out',
  // GitHub Pages requires a base path if not using a custom domain
  basePath: '/masters-draft',
  // Disable image optimization since GitHub Pages doesn't support it
  images: {
    unoptimized: true,
  },
  // Ensure trailing slashes for GitHub Pages compatibility
  trailingSlash: true,
};

module.exports = nextConfig;
